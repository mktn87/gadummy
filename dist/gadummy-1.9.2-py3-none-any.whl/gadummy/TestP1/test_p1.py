import json
import string

j = json.JSONEncoder
s = string.ascii_letters
print("hello20")

# LONG LINE LONG LINE LONG LINE LONG LINE LONG LINE LONG LINE LONG LINE LONG
